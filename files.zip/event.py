import enum
import uuid
from datetime import datetime

from sqlalchemy import DateTime, Enum, ForeignKey, String, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class EventSource(str, enum.Enum):
    PACKET = "PACKET"
    SERVICE = "SERVICE"
    LOG = "LOG"


class EventSeverity(str, enum.Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


class Event(Base):
    __tablename__ = "events"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    host_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("hosts.id"), nullable=True
    )
    # Which collector produced this event
    source: Mapped[EventSource] = mapped_column(Enum(EventSource), nullable=False)
    # Machine-readable event type, e.g. PORT_SCAN, SERVICE_DOWN, AUTH_FAILURE
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    severity: Mapped[EventSeverity] = mapped_column(
        Enum(EventSeverity), nullable=False
    )
    # Flexible JSON payload: raw packet summary, log line, probe result, etc.
    payload: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    detected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    host: Mapped["Host | None"] = relationship("Host", back_populates="events")  # noqa: F821
    alert: Mapped["Alert | None"] = relationship(  # noqa: F821
        "Alert", back_populates="event", uselist=False
    )

    def __repr__(self) -> str:
        return f"<Event {self.event_type} [{self.severity}] from {self.source}>"
