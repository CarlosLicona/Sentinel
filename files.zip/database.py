from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from app.config import settings


# ── Engine ────────────────────────────────────────────────────────────────────
# pool_pre_ping=True verifies connections before using them,
# avoiding "connection closed" errors after DB restarts.
engine = create_engine(
    settings.database_url,
    pool_pre_ping=True,
    echo=(settings.app_env == "development"),  # Log SQL only in dev
)

# ── Session factory ───────────────────────────────────────────────────────────
SessionLocal = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
)


# ── Base class for all ORM models ─────────────────────────────────────────────
class Base(DeclarativeBase):
    pass


# ── FastAPI dependency ────────────────────────────────────────────────────────
def get_db():
    """
    Yields a database session for use in route handlers.
    The session is always closed when the request finishes,
    even if an exception is raised.

    Usage in a router:
        def my_route(db: Session = Depends(get_db)):
            ...
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
