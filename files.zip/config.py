from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    All configuration is read from environment variables (or .env file).
    Pydantic validates types and raises clear errors on startup if anything
    is missing or malformed.
    """

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    app_env: str = "development"
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    log_level: str = "info"

    # Database
    database_url: str

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Packet collector
    capture_interface: str = "eth0"
    capture_filter: str = ""

    # Alert channels
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    alert_email_to: str = ""

    slack_webhook_url: str = ""
    alert_webhook_url: str = ""


# Single instance imported everywhere
settings = Settings()
