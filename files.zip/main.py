from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.config import settings
from app.database import engine
from app.models import *  # noqa: F401, F403 — ensures all models are registered


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Code before `yield` runs on startup.
    Code after `yield` runs on shutdown.
    """
    # Future: start background collectors here
    # e.g. asyncio.create_task(packet_collector.start())
    yield
    # Future: graceful shutdown of collectors


app = FastAPI(
    title="Sentinel",
    description="Infrastructure security monitoring with real-time packet analysis, service health checks, and intelligent alerting.",
    version="0.1.0",
    lifespan=lifespan,
)


# ── Routers ───────────────────────────────────────────────────────────────────
# Uncomment each router as it is implemented:
# from app.routers import hosts, services, events, alerts
# app.include_router(hosts.router, prefix="/hosts", tags=["Hosts"])
# app.include_router(services.router, prefix="/services", tags=["Services"])
# app.include_router(events.router, prefix="/events", tags=["Events"])
# app.include_router(alerts.router, prefix="/alerts", tags=["Alerts"])


@app.get("/", tags=["Health"])
def health_check():
    return {
        "status": "ok",
        "service": "sentinel",
        "version": "0.1.0",
        "env": settings.app_env,
    }
